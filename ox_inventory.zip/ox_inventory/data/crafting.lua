return {
	{
        name = 'debug_crafting',
		items = {
			{
				name = 'water',
				ingredients = {
					scrapmetal = 5,
					WEAPON_HAMMER = 0.05
				},
				duration = 5000,
				count = 2,
			},
		},
		points = {
			vec3(0, 0, 0),
			vec3(0, 0, 0)
		},
		zones = {
			{
				coords = vec3(0, 0, 0),
				size = vec3(0, 0, 0),
				distance = 1.5,
				rotation = 315.0,
			},
			{
				coords = vec3(0, 0, 0),
				size = vec3(0, 0, 0),
				distance = 1.5,
				rotation = 70.0,
			},
		},
		blip = { id = 566, colour = 31, scale = 0.8 },
	},
}
