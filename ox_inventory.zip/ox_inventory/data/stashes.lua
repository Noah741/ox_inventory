return {
    --[[{
		coords = vector3(463.29, -985.29, 30.73),
		target = {
			loc = vector3(463.29, -985.29, 30.73),
			length = 0.6,
			width = 1.8,
			heading = 340,
			minZ = 43.34,
			maxZ = 44.74,
			label = 'Ouvrir armurerie'
		},
		name = 'armurerielspd',
		label = 'Armurerie LSPD',
		owner = true,
		slots = 70,
		weight = 10000000,
		groups = {['police'] = 9}
	},]]--
}
