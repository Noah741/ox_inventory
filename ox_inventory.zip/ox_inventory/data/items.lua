return {

	['black_money'] = {
		label = 'Argent sale',
	},

	['money'] = {
		label = 'Argent',
	},

	['water'] = {
		label = 'Eau',
		weight = 250,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_ld_flow_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
			usetime = 2500,
			cancel = true,
			notification = 'Votre soif a augmenter'
		}
	},

	['burger'] = {
		label = 'Burger',
		weight = 500,
		client = {
			status = { hunger = 200000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
			notification = 'Votre faim a augmenter'
		},
	},

	['paperbag'] = {
		label = 'Sac en papier',
		weight = 250,
		stack = false,
		close = false,
		consume = 0
	},

	['bandage'] = {
		label = 'Bandage',
		weight = 500,
		client = {
			anim = { dict = 'missheistdockssetup1clipboard@idle_a', clip = 'idle_a', flag = 49 },
			prop = { model = `prop_rolled_sock_02`, pos = vec3(-0.14, -0.14, -0.08), rot = vec3(-50.0, -50.0, 0.0) },
			disable = { move = true, car = true, combat = true },
			usetime = 2500,
		}
	},

	["medikit"] = {
		label = "Kit de soin",
		weight = 1000,
		stack = true,
		close = true,
	},

	["compresse"] = {
		label = "Compresse",
		weight = 250,
		stack = true,
		close = true,
	},

	["repairkit"] = {
		label = "Kit de réparation",
		weight = 2500,
		stack = true,
		close = true,
	},

	["cleankit"] = {
		label = "Kit de nettoyage",
		weight = 1500,
		stack = true,
		close = true,
	},

	["ferraille"] = {
		label = "Ferraille",
		weight = 250,
		stack = true,
		close = true,
	},
	
	["acier"] = {
		label = "Acier",
		weight = 250,
		stack = true,
		close = true,
	},

	["meth"] = {
		label = "Meth",
		weight = 75,
		stack = true,
		close = true,
	},

	["meth_pooch"] = {
		label = "Pochon de Meth",
		weight = 250,
		stack = true,
		close = true,
	},

	["opium"] = {
		label = "Opium",
		weight = 75,
		stack = true,
		close = true,
	},

	["coke"] = {
		label = "Coke",
		weight = 75,
		stack = true,
		close = true,
	},

	["coke_pooch"] = {
		label = "Pochon de Coke",
		weight = 250,
		stack = true,
		close = true,
	},

	["weed_pooch"] = {
		label = "Pochon de Weed",
		weight = 250,
		stack = true,
		close = true,
	},

	["weed"] = {
		label = "Weed",
		weight = 75,
		stack = true,
		close = true,
	},

	["opium_pooch"] = {
		label = "Pochon d'Opium",
		weight = 250,
		stack = true,
		close = true,
	},

	["cuivre"] = {
		label = "Cuivre",
		weight = 1,
		stack = true,
		close = true,
	},

	["metal"] = {
		label = "Métal",
		weight = 1,
		stack = true,
		close = true,
	},

	["poudre"] = {
		label = "Poudre",
		weight = 1,
		stack = true,
		close = true,
	},

	["poudreor"] = {
		label = "Poudre D'or",
		weight = 1,
		stack = true,
		close = true,
	},

	["lingotor"] = {
		label = "Lingot D'or",
		weight = 1,
		stack = true,
		close = true,
	},

	["raisin"] = {
		label = "Raisin",
		weight = 1,
		stack = true,
		close = true,
	},

	["bouteillevin"] = {
		label = "Bouteille de Vin",
		weight = 1,
		stack = true,
		close = true,
	},

	["sacbraquage"] = {
		label = "Sac braquage",
		weight = 1,
		stack = true,
		close = true,
	},

	["perceuse"] = {
		label = "Perceuse",
		weight = 1,
		stack = true,
		close = true,
	},

	["tabac"] = {
		label = "Tabac",
		weight = 1,
		stack = true,
		close = true,
	},

	["cigarette"] = {
		label = "Paquet de cigarettes",
		weight = 1,
		stack = true,
		close = true,
	},

	["poulet"] = {
		label = "Poulet",
		weight = 1,
		stack = true,
		close = true,
	},

	["barquette"] = {
		label = "Barquette de poulet",
		weight = 1,
		stack = true,
		close = true,
	},
}